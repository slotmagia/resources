var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/payment/route.js")
R.c("server/chunks/[root-of-the-server]__58338756._.js")
R.c("server/chunks/node_modules_next_00a34c93._.js")
R.m(73934)
R.m(22587)
module.exports=R.m(22587).exports
