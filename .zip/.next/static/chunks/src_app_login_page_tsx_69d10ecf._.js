(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_31cd8328._.js",
  "static/chunks/node_modules_44200634._.js"
],
    source: "dynamic"
});
