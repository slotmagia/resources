__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/284c4a4fbb4c3fe4.js",
  "static/chunks/turbopack-779307cf854dd045.js"
])
