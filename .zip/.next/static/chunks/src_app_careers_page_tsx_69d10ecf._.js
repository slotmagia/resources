(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_39f3292d._.js",
  "static/chunks/node_modules_ae98eab2._.js"
],
    source: "dynamic"
});
