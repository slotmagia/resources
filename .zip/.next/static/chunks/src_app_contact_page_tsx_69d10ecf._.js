(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_9183c2ad._.js",
  "static/chunks/node_modules_b962f623._.js"
],
    source: "dynamic"
});
