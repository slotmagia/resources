(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_6bec241c._.js",
  "static/chunks/node_modules_44200634._.js"
],
    source: "dynamic"
});
