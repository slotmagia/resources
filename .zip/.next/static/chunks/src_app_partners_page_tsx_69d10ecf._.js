(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_a9737222._.js",
  "static/chunks/node_modules_ae98eab2._.js"
],
    source: "dynamic"
});
